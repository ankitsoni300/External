//
//  NetworkManager.swift
//  O4S
//
//  Created by Ankit Soni on 03/03/21.
//

import Foundation
import Alamofire

public final class NetworkManager{
    
    private init(){}
    
    static let instance: NetworkManager = {
        let sharedInstance = NetworkManager ()
        return sharedInstance
    }()
    
    func getDataFromApi<T : Codable>(requestUrl : String, rerultType : T.Type, completion : @escaping((Result<T,Error>)->())){
        AF.request(requestUrl).response { (response) in
            if let data = response.data {
                do{
                    let result = try JSONDecoder().decode(T.self, from: data)
                    completion(.success(result))
                }catch let err{
                    completion(.failure(err))
                }
            }
        }
    }
}

enum ApiUrls : String{
    case imagesUrl = "http://pastebin.com/raw/wgkJgazE"
}
