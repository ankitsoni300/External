//
//  ImagesModel.swift
//  O4S
//
//  Created by Ankit Soni on 03/03/21.
//

import Foundation

struct ImagesModel : Codable {
    var likes : Int?
    var user : User?
    var urls : Urls?
    
    enum CodingKeys : String, CodingKey {
        case likes = "likes"
        case user = "user"
        case urls = "urls"
    }
}

struct User : Codable{
    var name : String?
    enum CodingKeys : String, CodingKey {
        case name = "name"
    }
}

struct Urls : Codable {
    var raw : String?
    var full : String?
    var regular : String?
    var small : String?
    var thumb : String?
    
    enum CodingKeys : String, CodingKey {
        case raw = "raw"
        case full = "full"
        case regular = "regular"
        case small = "small"
        case thumb = "thumb"
    }
}
