//
//  CustomCollectionViewCell.swift
//  O4S
//
//  Created by Ankit Soni on 03/03/21.
//

import UIKit
import Kingfisher

class CustomCollectionViewCell: UICollectionViewCell {
    
    //MARK:- @IBOutlets
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblLikes: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    //MARK:- DATA
    func setData(imageViewModel : ImageViewModel?){
        self.lblName.text = imageViewModel?.name
        self.lblLikes.text = imageViewModel?.likes
        
        let image = imageViewModel?.small ?? ""
        let url = URL(string: image)
        let processor = DownsamplingImageProcessor(size: self.imgView.bounds.size)
            |> RoundCornerImageProcessor(cornerRadius: 20)
        
        self.imgView.kf.indicatorType = .activity
        
        //Image image caching
        self.imgView.kf.setImage(
            with: url,
            placeholder: UIImage(named: "image_placeholder"),
            options: [
                .processor(processor),
                .scaleFactor(UIScreen.main.scale),
                .transition(.fade(1)),
                .cacheOriginalImage
            ], completionHandler:
                {
                    result in
                    switch result {
                    case .success(let value):
                        print("Task done for: \(value.source.url?.absoluteString ?? "")")
                    case .failure(let error):
                        print("Job failed: \(error.localizedDescription)")
                    }
                })
    }
    
}
