//
//  ViewController.swift
//  O4S
//
//  Created by Ankit Soni on 03/03/21.
//

import UIKit

class ViewController: UIViewController {

    //MARK:- @IBOutlets
    @IBOutlet weak var loader: UIActivityIndicatorView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    //MARK:- Variables
    var arrImageViewModel : [ImageViewModel]? = [ImageViewModel]()
    var arrImages : [UIImage] = [UIImage]()
    
    //MARK:- ViewLifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        if let layout = self.collectionView.collectionViewLayout as? PinterestLayout{
            layout.delegate = self
        }
        self.collectionView.contentInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        self.getData()
    }
    
    //MARK:- APICall
    private func getData(){
        self.loader.isHidden = false
        NetworkManager.instance.getDataFromApi(requestUrl: ApiUrls.imagesUrl.rawValue, rerultType: [ImagesModel].self) { (result) in
            switch result {
            case .success(let imageModel):
                self.arrImageViewModel = imageModel.map({ (imageData) in
                    return ImageViewModel(imageModel : imageData)
                })
                self.downLoadImages(arrViewModel: self.arrImageViewModel)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    //MARK:- Images download in background
    private func downLoadImages(arrViewModel : [ImageViewModel]?){
        let dispatchGroup = DispatchGroup()
        arrViewModel?.forEach({ (imageData) in
            DispatchQueue.global(qos: .background).async(group: dispatchGroup){
                dispatchGroup.enter()
                guard let url = URL(string: imageData.small ?? "") else{
                    return
                }
                if let imageData = try? Data(contentsOf: url){
                    guard let image = UIImage(data: imageData) else{
                        return
                    }
                    self.arrImages.append(image)
                }else{
                    self.arrImages.append(UIImage.init(named: "image_placeholder")!)
                }
                
                dispatchGroup.leave()
            }
        })
        
        dispatchGroup.notify(queue: .main){
            self.loader.isHidden = true
            self.collectionView.reloadData()
        }
    }

}

extension ViewController : PinterestLayoutDelegate{
    
    func collectionView(_ collectionView: UICollectionView, heightForPhotoAtIndexPath indexPath: IndexPath) -> CGFloat {
        if self.arrImages.count > indexPath.row{
            let height = self.arrImages[indexPath.row].size.height
            return height
        }
        return 0
    }
    
}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrImageViewModel?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCollectionViewCell", for: indexPath) as? CustomCollectionViewCell else {
            return UICollectionViewCell()
        }
        cell.setData(imageViewModel: self.arrImageViewModel?[indexPath.row])
        cell.clipsToBounds = true
        cell.layer.cornerRadius = 15
        return cell
    }
    
}

