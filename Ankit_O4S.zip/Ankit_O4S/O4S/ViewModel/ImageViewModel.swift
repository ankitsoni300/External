//
//  ImageViewModel.swift
//  O4S
//
//  Created by Ankit Soni on 04/03/21.
//

import Foundation
import UIKit
import Kingfisher

class ImageViewModel{
    var name : String?
    var likes : String?
    var raw : String?
    var full : String?
    var regular : String?
    var small : String?
    var thumb : String?
    var myImage : UIImage?
    
    init(imageModel : ImagesModel? = nil) {
        self.name = imageModel?.user?.name
        self.likes = "Likes -> \(imageModel?.likes ?? 0)"
        self.raw = imageModel?.urls?.raw
        self.full = imageModel?.urls?.full
        self.regular = imageModel?.urls?.regular
        self.small = imageModel?.urls?.small
        self.thumb = imageModel?.urls?.thumb
    }
    
}
